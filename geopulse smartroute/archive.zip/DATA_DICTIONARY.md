\# Bhubaneswar Traffic Dataset — Data Dictionary



\## Dataset Overview

City-scale hourly traffic dataset for Bhubaneswar collected using the TomTom Traffic Flow API.

Data spans multiple days and covers 700 road segments.



All timestamps are stored in \*\*UTC\*\*.

Hourly alignment is achieved via explicit hour bucketing.



---



\## Primary Keys



\### segment\_id

\- \*\*Type:\*\* int

\- \*\*Description:\*\* Unique identifier for a road segment

\- \*\*Range:\*\* 0–699

\- \*\*Notes:\*\* Stable across the entire dataset



\### hour

\- \*\*Type:\*\* datetime (UTC)

\- \*\*Description:\*\* Hourly time bucket used for alignment and analysis

\- \*\*Granularity:\*\* 1 hour

\- \*\*Notes:\*\* All analytics and ML should be based on this column



---



\## Timestamp Fields



\### timestamp

\- \*\*Type:\*\* datetime (UTC)

\- \*\*Description:\*\* Actual observation timestamp returned by the API

\- \*\*Nullable:\*\* Yes

\- \*\*Notes:\*\* Null for synthetic grid rows (missing data)



---



\## Traffic Signal Fields



\### currentSpeed

\- \*\*Type:\*\* integer

\- \*\*Units:\*\* km/h

\- \*\*Description:\*\* Observed traffic speed on the segment

\- \*\*Nullable:\*\* Yes (missing rows)



\### freeFlowSpeed

\- \*\*Type:\*\* integer

\- \*\*Units:\*\* km/h

\- \*\*Description:\*\* Expected speed under free-flow conditions

\- \*\*Nullable:\*\* Yes



\### currentTravelTime

\- \*\*Type:\*\* integer

\- \*\*Units:\*\* seconds

\- \*\*Description:\*\* Observed travel time for the segment

\- \*\*Nullable:\*\* Yes



\### freeFlowTravelTime

\- \*\*Type:\*\* integer

\- \*\*Units:\*\* seconds

\- \*\*Description:\*\* Expected travel time under free-flow conditions

\- \*\*Nullable:\*\* Yes



\### confidence

\- \*\*Type:\*\* float

\- \*\*Range:\*\* ~0.5–1.0

\- \*\*Description:\*\* Confidence score provided by TomTom

\- \*\*Nullable:\*\* Yes



---



\## Data Quality Flags



\### is\_observed

\- \*\*Type:\*\* boolean

\- \*\*Description:\*\* True if traffic data was actually collected for this segment-hour

\- \*\*Usage:\*\* Use this to filter observed-only data



\### is\_missing

\- \*\*Type:\*\* boolean

\- \*\*Description:\*\* True if this row represents a missing (segment, hour) pair

\- \*\*Notes:\*\* Missing data is explicit and not interpolated



\### roadClosure

\- \*\*Type:\*\* boolean

\- \*\*Description:\*\* Indicates if the road segment was marked closed

\- \*\*Nullable:\*\* Yes



---



\## Static Road Metadata



\### osmid

\- \*\*Type:\*\* string / identifier

\- \*\*Description:\*\* OpenStreetMap identifier for the road segment



\### road\_name

\- \*\*Type:\*\* identifier (numeric or string)

\- \*\*Description:\*\* Road name or internal road identifier

\- \*\*Notes:\*\* Not guaranteed to be human-readable



\### road\_type

\- \*\*Type:\*\* string

\- \*\*Description:\*\* OSM road classification (e.g., primary, secondary)



\### length\_m

\- \*\*Type:\*\* float

\- \*\*Units:\*\* meters

\- \*\*Description:\*\* Length of the road segment



\### lat

\- \*\*Type:\*\* float

\- \*\*Description:\*\* Latitude of segment centroid



\### lon

\- \*\*Type:\*\* float

\- \*\*Description:\*\* Longitude of segment centroid



---



\## Important Notes



\- No values are interpolated in this dataset.

\- Missing data is explicitly represented via grid expansion.

\- All analytics should respect `is\_observed` unless intentionally modeling missingness.



