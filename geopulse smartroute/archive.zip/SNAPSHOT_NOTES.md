\# Snapshot v1 — Bhubaneswar Traffic Dataset



\- Snapshot date: YYYY-MM-DD

\- Description: Canonical structured dataset with full hourly grid

\- Steps completed:

&nbsp; - Data quality validation

&nbsp; - Cleaning \& deduplication

&nbsp; - Timestamp normalization

&nbsp; - Explicit missingness grid

&nbsp; - Structured canonical layout

&nbsp; - Parquet + DuckDB conversion



This snapshot is immutable.



